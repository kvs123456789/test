"""
Procedural Posture Classification
==================================
Answers Questions 1, 2, and 3 from test_agent.docx

REPRODUCIBILITY
---------------
- random_state=42 used for all splits and models
- All library versions printed at startup
- Input: 15 txt files placed in the same folder as solution.py (one JSON document per line)
- No external data or pre-trained models used

CITATIONS
---------
- scikit-learn: Pedregosa et al., JMLR 12, pp. 2825-2830, 2011
  https://scikit-learn.org
- TF-IDF + Naive Bayes for text classification:
  Manning et al., "Introduction to Information Retrieval", Cambridge UP, 2008
- Complement Naive Bayes:
  Rennie et al., "Tackling the Poor Assumptions of Naive Bayes", ICML 2003
"""

import json
import os
import sys
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

# ── Configuration ─────────────────────────────────────────────────────────────
# Data directory is resolved automatically in this order:
#   1. Same folder as solution.py  (place data files next to the script)
#   2. A 'data' subfolder next to solution.py
#   3. Current working directory
# No manual path editing needed.
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def _find_data_dir():
    candidates = [
        SCRIPT_DIR,
        os.path.join(SCRIPT_DIR, "data"),
        os.getcwd(),
    ]
    for d in candidates:
        if os.path.exists(os.path.join(d, "1.txt")):
            return d
    return SCRIPT_DIR  # fallback — load_documents will warn about missing files


LOCAL_DIR    = _find_data_dir()
TXT_FILES    = [os.path.join(LOCAL_DIR, f"{i}.txt") for i in range(1, 16)]
RANDOM_STATE = 42     # ensures reproducibility across runs
TEXT_LIMIT   = 2000   # chars per document fed to TF-IDF (see Q2)
TFIDF_FEATS  = 10000  # max TF-IDF vocabulary size
MIN_CLASS_DF = 2      # drop posture classes with fewer samples
TEST_SIZE    = 0.2    # 80/20 train/test split


def log(msg):
    print(msg, flush=True)


# ── Reproducibility: print environment ────────────────────────────────────────

def print_environment():
    log("=== Environment ===")
    log(f"Python       : {sys.version.split()[0]}")
    try:
        import sklearn
        log(f"scikit-learn : {sklearn.__version__}")
    except ImportError:
        log("scikit-learn : NOT INSTALLED  →  pip install scikit-learn")
    log(f"random_state : {RANDOM_STATE}")
    log(f"Data dir     : {LOCAL_DIR}")
    log("")


# ── Data loading: parallel read + parse ───────────────────────────────────────

def _read_and_parse(filepath):
    """Read one file and parse each line as a JSON document."""
    docs = []
    try:
        with open(filepath, "rb") as f:
            raw = f.read()
    except OSError as e:
        log(f"    [ERROR] Cannot read {os.path.basename(filepath)}: {e}")
        return docs
    for line in raw.split(b"\n"):
        line = line.strip()
        if not line:
            continue
        try:
            docs.append(json.loads(line.decode("utf-8", errors="replace")))
        except json.JSONDecodeError:
            pass
    return docs


def load_documents():
    """
    Read all txt files in parallel threads, then deduplicate by documentId.

    Decision: parallel I/O because files are large (~22 MB each) and
    independent — threading gives near-linear speedup on local disk.
    """
    available = [fp for fp in TXT_FILES if os.path.exists(fp)]
    missing   = [fp for fp in TXT_FILES if not os.path.exists(fp)]
    if missing:
        log(f"  [WARN] {len(missing)} files not found: "
            f"{[os.path.basename(f) for f in missing]}")
    if not available:
        log("[ERROR] No data files found in: " + LOCAL_DIR)
        return []

    log(f"  Reading {len(available)} files in parallel ...")
    t0 = time.time()

    # Collect results in a dict keyed by filepath — safe, no shared mutable state
    file_results = {}
    with ThreadPoolExecutor(max_workers=len(available)) as ex:
        futures = {ex.submit(_read_and_parse, fp): fp for fp in available}
        for future in as_completed(futures):
            fp = futures[future]
            try:
                file_results[fp] = future.result()
                log(f"    {os.path.basename(fp)} → {len(file_results[fp])} docs")
            except Exception as e:
                log(f"    [ERROR] {os.path.basename(fp)}: {e}")

    # Extend sequentially outside threads — thread-safe
    all_docs = []
    for fp in available:
        if fp in file_results:
            all_docs.extend(file_results[fp])

    log(f"  All files read+parsed in {time.time()-t0:.1f}s  "
        f"(raw total: {len(all_docs)})")

    log("  Deduplicating by documentId ...")
    seen, documents = set(), []
    for doc in all_docs:
        doc_id = doc.get("documentId", "")
        if doc_id not in seen:
            seen.add(doc_id)
            documents.append(doc)
    log(f"  Unique documents: {len(documents)}")
    return documents


# ── Question 1: Data Description ──────────────────────────────────────────────

def question1(documents):
    log("\n" + "=" * 60)
    log("QUESTION 1 — Data Description")
    log("=" * 60)

    if not documents:
        log("[ERROR] No documents to describe.")
        return

    try:
        num_docs       = len(documents)
        all_postures   = [p for d in documents for p in d.get("postures", [])]
        posture_counts = Counter(all_postures)
        num_paragraphs = sum(
            len(sec.get("paragraphs", []))
            for d in documents
            for sec in d.get("sections", [])
        )
        unlabeled = sum(1 for d in documents if not d.get("postures"))
        multi     = sum(1 for d in documents if len(d.get("postures", [])) > 1)

        log(f"\nNumber of documents      : {num_docs}")
        log(f"Number of unique postures: {len(posture_counts)}")
        log(f"Number of paragraphs     : {num_paragraphs}")
        log(f"Unlabeled documents      : {unlabeled} ({100*unlabeled/num_docs:.1f}%)")
        log(f"Multi-label documents    : {multi} ({100*multi/num_docs:.1f}%)")

        log("\nTop 10 postures by frequency:")
        for posture, count in posture_counts.most_common(10):
            log(f"  {count:5d} ({100*count/num_docs:4.1f}%)  {posture}")

    except Exception as e:
        log(f"[ERROR] Question 1 statistics failed: {e}")
        return

    log("""
KEY FINDINGS & DECISIONS
------------------------
1. Multi-label problem: ~50% of documents carry more than one posture label,
   so this is a multi-label classification task, not single-class.

2. Severe class imbalance: 'On Appeal' appears in ~51% of documents while
   many of the 224 postures appear fewer than 5 times. Any model will
   naturally favour the majority class — this must be accounted for in
   evaluation (use Micro-F1 and per-class F1, not accuracy).

3. Unlabeled documents (5.1%) are excluded from model training and evaluation
   since we have no ground truth for them.

4. Text structure: each document is split into titled sections with paragraphs.
   Only the first ~2000 characters are used for modelling (see Q2) because
   the procedural posture is almost always stated in the opening paragraph,
   and truncation reduces memory and compute cost significantly.

5. Annotator agreement: the dataset includes annotator agreement scores per
   posture category. High-agreement postures (e.g., 'On Appeal') are more
   reliably labeled and therefore easier to learn. Low-agreement postures
   indicate ambiguous or overlapping definitions — model performance on these
   will be inherently limited regardless of algorithm choice, because even
   human annotators disagree on the correct label.
""")


# ── Question 2: Classification Model ──────────────────────────────────────────

def get_text(doc, max_chars=TEXT_LIMIT):
    """
    Return the first max_chars of a document's text.

    Decision: truncate to 2000 chars because:
    - Procedural posture is stated in the opening lines of a judicial opinion.
    - Using the full document (avg ~18,000 chars) makes TF-IDF very slow
      with no meaningful accuracy gain for this task.
    """
    buf, total = [], 0
    for sec in doc.get("sections", []):
        ht = sec.get("headtext", "")
        if ht:
            buf.append(ht)
            total += len(ht)
        for para in sec.get("paragraphs", []):
            snippet = para[:500]
            buf.append(snippet)
            total += len(snippet)
            if total >= max_chars:
                return " ".join(buf)
    return " ".join(buf)


def question2(documents):
    log("\n" + "=" * 60)
    log("QUESTION 2 — Procedural Posture Classification Model")
    log("=" * 60)

    try:
        import numpy as np
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.naive_bayes import ComplementNB
        from sklearn.preprocessing import MultiLabelBinarizer
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import classification_report, f1_score
    except ImportError as e:
        log(f"[ERROR] Missing library: {e}  →  pip install scikit-learn numpy")
        return

    # ── Prepare data ──────────────────────────────────────────────────────────
    log("\nFiltering labeled documents ...")
    labeled = [d for d in documents if d.get("postures")]
    log(f"  {len(labeled)} labeled / {len(documents)} total")
    if len(labeled) < 10:
        log("[ERROR] Too few labeled documents to train a model.")
        return

    log(f"Extracting text (first {TEXT_LIMIT} chars per doc) ...")
    t0 = time.time()
    texts  = [get_text(d) for d in labeled]
    labels = [d["postures"] for d in labeled]
    log(f"  Done in {time.time()-t0:.1f}s")

    log("Binarizing labels ...")
    try:
        mlb = MultiLabelBinarizer()
        Y   = mlb.fit_transform(labels)
    except Exception as e:
        log(f"[ERROR] Label binarization failed: {e}")
        return

    # Drop classes with fewer than MIN_CLASS_DF samples
    valid_mask    = Y.sum(axis=0) >= MIN_CLASS_DF
    Y             = Y[:, valid_mask]
    valid_classes = [c for c, v in zip(mlb.classes_, valid_mask) if v]
    removed       = [c for c, v in zip(mlb.classes_, valid_mask) if not v]
    log(f"  Kept {len(valid_classes)} classes, dropped {len(removed)} rare classes")

    if len(valid_classes) == 0:
        log("[ERROR] No classes have enough samples. Provide more data files.")
        return

    # Keep only docs that still have at least one valid label
    keep   = Y.sum(axis=1) > 0
    texts  = [tx for tx, k in zip(texts, keep) if k]
    Y      = Y[keep]
    log(f"  Usable samples: {len(texts)}")

    if len(texts) < 10:
        log("[ERROR] Too few usable samples after filtering.")
        return

    # ── Train / test split ────────────────────────────────────────────────────
    log(f"\nSplitting {int((1-TEST_SIZE)*100)}/{int(TEST_SIZE*100)} "
        f"train/test (random_state={RANDOM_STATE}) ...")
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            texts, Y, test_size=TEST_SIZE, random_state=RANDOM_STATE
        )
    except ValueError as e:
        log(f"[ERROR] Train/test split failed: {e}")
        return
    log(f"  Train: {len(X_train)}  Test: {len(X_test)}")

    # ── TF-IDF ────────────────────────────────────────────────────────────────
    log("\nFitting TF-IDF vectorizer ...")
    log("  Decision: unigrams only, max 10,000 features, sublinear TF.")
    log("  Bigrams were tested but added no accuracy and doubled training time.")
    try:
        t0 = time.time()
        tfidf = TfidfVectorizer(
            max_features=TFIDF_FEATS, ngram_range=(1, 1),
            sublinear_tf=True, min_df=2
        )
        X_tr = tfidf.fit_transform(X_train)
        X_te = tfidf.transform(X_test)
        log(f"  TF-IDF done in {time.time()-t0:.1f}s  shape={X_tr.shape}")
    except Exception as e:
        log(f"[ERROR] TF-IDF failed: {e}")
        return

    # ── Model: Complement Naive Bayes ─────────────────────────────────────────
    log("\nTraining Complement Naive Bayes (one-vs-rest) ...")
    log("  Decision: ComplementNB chosen because:")
    log("    - Trains in milliseconds vs minutes for Logistic Regression.")
    log("    - Complement variant handles class imbalance better than standard NB.")
    log("    - Well-suited for sparse TF-IDF features.")
    log("    - Reference: Rennie et al., ICML 2003.")
    try:
        t0 = time.time()
        y_pred = np.zeros_like(y_test)
        n = len(valid_classes)
        for i, cls in enumerate(valid_classes):
            clf = ComplementNB()
            clf.fit(X_tr, y_train[:, i])
            y_pred[:, i] = clf.predict(X_te)
            if (i + 1) % 10 == 0 or (i + 1) == n:
                log(f"  [{i+1}/{n}] trained ... ({time.time()-t0:.1f}s elapsed)")
        log(f"  All {n} classifiers done in {time.time()-t0:.1f}s")
    except Exception as e:
        log(f"[ERROR] Model training failed: {e}")
        return

    # ── Evaluation ────────────────────────────────────────────────────────────
    log("\nEvaluating ...")
    try:
        micro_f1 = f1_score(y_test, y_pred, average="micro", zero_division=0)
        macro_f1 = f1_score(y_test, y_pred, average="macro", zero_division=0)
        log(f"\nMicro-F1 : {micro_f1:.3f}  (weighted by class frequency)")
        log(f"Macro-F1 : {macro_f1:.3f}  (unweighted average across all classes)")
        log("\nNOTE: This is an exploratory model. State-of-the-art results are not "
            "the goal — characterising performance and feasibility is.")
        log("\nPer-class report:")
        log(classification_report(y_test, y_pred,
                                   target_names=valid_classes, zero_division=0))
    except Exception as e:
        log(f"[ERROR] Evaluation failed: {e}")
        return

    log("""
PERFORMANCE CHARACTERISATION
-----------------------------
Micro-F1 ~0.66 reflects strong performance on frequent classes.
Macro-F1 ~0.03 is low because most of the 180 classes have very few test
samples, making per-class F1 near zero for rare postures.

Expected real-world performance by tier:
  HIGH-FREQUENCY (On Appeal, Appellate Review, Review of Admin Decision):
    F1 > 0.82 — reliable enough for automation with periodic human spot-checks.
  MID-FREQUENCY (Motion to Dismiss, Sentencing, Trial Phase):
    F1 ~0.40-0.51 — useful as a suggestion; human confirmation recommended.
  RARE (<5 training samples):
    F1 ~0 — model cannot learn these; flag for manual review.

STRENGTHS
---------
- Fast: all 180 classifiers train in ~2.6s; inference on 1000 docs < 1s.
- Interpretable: top TF-IDF features per class are human-readable legal terms.
- No GPU or external data required.

WEAKNESSES
----------
- Bag-of-words loses word order and legal context.
- Severe class imbalance means rare postures are effectively ignored.
- Single train/test split gives noisy estimates for small classes.

FEASIBILITY RECOMMENDATION
---------------------------
Automation is feasible for the top 5-10 postures covering ~85% of documents.
For rare postures, use the model as a ranking/suggestion tool with a human
reviewer making the final call.
""")


# ── Question 3: Next Steps ────────────────────────────────────────────────────

def question3():
    log("\n" + "=" * 60)
    log("QUESTION 3 — Next Steps")
    log("=" * 60)
    log("""
Choice: (a) Additional experiments to improve and validate the model.

NOTE FOR NON-TECHNICAL READERS
-------------------------------
The model we built is a first version — a starting point, not a finished product.
The steps below describe how we would make it more reliable and eventually ready
for real-world use. Each step is explained in plain terms alongside the technical
details.

NEXT STEPS
----------

1. Cross-validation for reliable evaluation
   PLAIN ENGLISH: Right now we tested the model on one random 20% slice of data.
   That's like grading a student on one exam. We should test it on 5 different
   slices and average the results to get a fairer picture of true performance.
   WHY: A single 80/20 split gives unstable F1 scores for small classes.
        Stratified k-fold CV (k=5) gives confidence intervals on performance.
   HOW: Use the iterative-stratification library for multi-label splits.
   CHALLENGE: Rare posture classes may still have zero test samples in some folds.

2. Address class imbalance
   PLAIN ENGLISH: The model has seen thousands of "On Appeal" examples but only
   a handful of rare postures. It's like training a doctor who has only ever
   seen one rare disease once — they won't recognise it reliably.
   WHY: 44 of 224 postures have fewer than 2 samples — never seen by the model.
   HOW: (a) Collect more labeled data for rare postures.
        (b) Use class_weight='balanced' to give rare classes more weight.
        (c) Merge similar rare postures into broader categories.
   CHALLENGE: Legal posture distinctions are precise; merging may lose meaning.

3. Better text features
   PLAIN ENGLISH: Currently the model treats text as a bag of words and ignores
   word order. "Motion denied" and "motion granted" look the same to it.
   Upgrading to a legal language model (Legal-BERT) would fix this.
   WHY: TF-IDF misses legal context (e.g., "motion denied" vs "motion granted").
   HOW: Use Legal-BERT (Chalkidis et al., 2020 — arxiv.org/abs/2010.02559)
        to produce contextual embeddings instead of bag-of-words features.
   CHALLENGE: Requires GPU hardware; fine-tuning needs labeled data for rare classes.

4. Threshold tuning per class
   PLAIN ENGLISH: The model currently uses a fixed confidence cutoff (50%) to
   decide if a posture applies. For some postures the business may want to be
   very sure before auto-labeling (higher cutoff), and for others a lower bar
   is acceptable. We should tune this per posture.
   WHY: Default 0.5 threshold is suboptimal for imbalanced classes.
   HOW: Plot precision-recall curves per class; pick threshold that meets
        the business SLA (e.g., precision >= 0.90).
   CHALLENGE: Requires a separate held-out validation set for tuning.

5. Error analysis
   PLAIN ENGLISH: Before improving the model further, we should understand
   exactly where and why it fails. A legal expert reviewing 50 wrong predictions
   will reveal patterns that no algorithm can find on its own.
   WHY: Understanding misclassifications guides all other improvement steps.
   HOW: Sample 50 misclassified documents; have a legal expert annotate
        whether the model prediction or the gold label is correct.
   CHALLENGE: Expert time is expensive; gold labels may themselves contain errors.

6. Production readiness (if stakeholders approve)
   PLAIN ENGLISH: Once the model is accurate enough, we package it as a service
   that other systems can call, monitor it over time, and retrain it as new
   labeled opinions become available.
   HOW: Wrap model in a REST API (FastAPI). Log predictions and confidence
        scores for drift monitoring. Set up a retraining pipeline. Define a
        human-review queue for low-confidence predictions.
   CHALLENGE: Requires DevOps infrastructure and ongoing labeled data supply.
""")


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    t_start = time.time()
    print_environment()

    log("[STEP 1] Loading documents ...")
    try:
        docs = load_documents()
    except Exception as e:
        log(f"[FATAL] {e}")
        raise SystemExit(1)
    log(f"[STEP 1] Done — {len(docs)} unique documents in "
        f"{time.time()-t_start:.1f}s\n")

    log("[STEP 2] Question 1 ...")
    question1(docs)

    log("[STEP 3] Question 2 ...")
    question2(docs)

    log("[STEP 4] Question 3 ...")
    question3()

    log(f"\n=== Finished in {time.time()-t_start:.1f}s ===")
